<?php
    //set off all error for security purposes
	error_reporting(E_ALL);
	

	//define some contstant
    define( "DB_DSN", "mysql:host=localhost;dbname=uniinmry_krazytable" );
    define( "DB_USERNAME", "uniinmry_ktroot" );
    define( "DB_PASSWORD", "root@007#" );
	define( "CLS_PATH", "class" );
	
	//include the classes
	include_once( CLS_PATH . "/user.php" );
	

?>