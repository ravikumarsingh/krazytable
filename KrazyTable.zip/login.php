<?php
$json = file_get_contents('php://input');
$obj = json_decode($json);
$posts[] = array('status'=>1,'name'=>"ravi",'value'=>420);
echo json_encode($posts);

?>